# 🔒 yanbao AI 环境配置锁定 (Environment Lockdown)

**版本**: v2.4.1 Gold Master  
**日期**: 2026年1月15日  
**目的**: 确保 yanbao AI 在任何时候、任何环境下都能精确重现当前的构建状态

---

## 📦 包含文件

本目录包含了 yanbao AI 的"基因图谱"，即所有关键的环境配置文件：

| 文件名 | 说明 | 用途 |
| :--- | :--- | :--- |
| `app.config.ts` | Expo 应用配置 | 定义应用名称、版本号、图标、启动屏幕等 |
| `eas.json` | EAS Build 配置 | 定义生产/开发/预览构建的环境变量和配置 |
| `package.json` | npm 包依赖清单 | 锁定所有依赖包的版本号 |
| `quick_build.sh` | 一键构建脚本 | 自动化执行环境准备、缓存清理和生产构建 |
| `README.md` | 本说明文档 | 指导如何使用这些配置文件 |

---

## 🚀 使用指南

### 场景 1：在新电脑上重新构建 yanbao AI

1. **克隆代码仓库**
   ```bash
   git clone https://github.com/Tsaojason-cao/yanbao-imaging-studio.git
   cd yanbao-imaging-studio
   ```

2. **恢复环境配置**（如果配置文件丢失）
   ```bash
   cp environment_lockdown/* .
   ```

3. **运行一键构建脚本**
   ```bash
   chmod +x environment_lockdown/quick_build.sh
   ./environment_lockdown/quick_build.sh
   ```

### 场景 2：手动构建（逐步执行）

1. **安装依赖**
   ```bash
   pnpm install
   # 或 npm install
   ```

2. **清理缓存**
   ```bash
   rm -rf node_modules/.cache .expo /tmp/metro-*
   ```

3. **登录 EAS**
   ```bash
   npx eas-cli login
   ```

4. **启动生产构建**
   ```bash
   npx eas-cli build --platform all --profile production
   ```

---

## 🔑 关键配置说明

### app.config.ts
- **版本号**: `2.4.1`
- **Bundle ID (iOS)**: `com.jasoncao.yanbao`
- **Package Name (Android)**: `com.jasoncao.yanbao`
- **主题**: 库洛米哥特风格（深紫色 #1a101f）

### eas.json
- **Production Profile**: 用于正式发布
  - 自动版本号管理
  - 生产环境变量
  - 代码签名配置

### package.json
- **核心依赖**:
  - `expo`: ~54.0.31
  - `react-native`: 0.81.5
  - `expo-image-manipulator`: ^14.0.8
  - `expo-media-library`: ^18.2.1

---

## ⚠️ 重要提示

1. **不要修改版本号**：`package.json` 中的依赖版本已经过充分测试，随意升级可能导致兼容性问题。
2. **保持配置同步**：如果修改了 `app.config.ts` 或 `eas.json`，请同步更新此目录中的备份文件。
3. **定期备份**：建议每次重大更新后，都将此目录打包备份到云端。

---

## 💜 by Jason Tsao who loves you the most
